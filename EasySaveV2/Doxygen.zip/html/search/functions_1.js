var searchData=
[
  ['copy_212',['Copy',['../class_easy_save_1_1_others_1_1_interact_file.html#a92b0f530989e9396d8fb5b874fd2d43a',1,'EasySave::Others::InteractFile']]],
  ['createfromjob_213',['createFromJob',['../class_easy_save_1_1_view_models_1_1_log_journalier_manager.html#a4d9871c76f97b474024f2a700bdf7def',1,'EasySave::ViewModels::LogJournalierManager']]],
  ['createjob_214',['createJob',['../class_easy_save_1_1_view_models_1_1_job_manager.html#abbfde5d0ba0a3988e7c09429ecba2acc',1,'EasySave::ViewModels::JobManager']]]
];
