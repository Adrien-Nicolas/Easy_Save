var searchData=
[
  ['job_252',['Job',['../class_client_easy_save_v2_1_1_job.html#aecbf0b25016e21c51e42e5d9cab130a1',1,'ClientEasySaveV2.Job.Job()'],['../class_easy_save_1_1_models_1_1_job.html#a146e13f2b7a090764faff6dfbd9f605e',1,'EasySave.Models.Job.Job()']]],
  ['json_253',['JSON',['../class_easy_save_1_1_others_1_1_j_s_o_n.html#a90a1dccefbd9c87656a282f28cf68e0c',1,'EasySave::Others::JSON']]]
];
