var searchData=
[
  ['job_66',['Job',['../class_client_easy_save_v2_1_1_job.html',1,'ClientEasySaveV2.Job'],['../class_easy_save_1_1_models_1_1_job.html',1,'EasySave.Models.Job'],['../class_client_easy_save_v2_1_1_job.html#aecbf0b25016e21c51e42e5d9cab130a1',1,'ClientEasySaveV2.Job.Job()'],['../class_easy_save_1_1_models_1_1_job.html#a146e13f2b7a090764faff6dfbd9f605e',1,'EasySave.Models.Job.Job()']]],
  ['jobmanager_67',['JobManager',['../class_easy_save_1_1_view_models_1_1_job_manager.html',1,'EasySave::ViewModels']]],
  ['json_68',['JSON',['../class_easy_save_1_1_others_1_1_j_s_o_n.html',1,'EasySave.Others.JSON'],['../class_easy_save_1_1_others_1_1_j_s_o_n.html#a90a1dccefbd9c87656a282f28cf68e0c',1,'EasySave.Others.JSON.JSON()']]],
  ['jsonresponse_69',['JsonResponse',['../class_json_response.html',1,'JsonResponse'],['../class_server_1_1_json_response.html',1,'Server.JsonResponse']]],
  ['jsonrpc_70',['JsonRPC',['../class_json_r_p_c.html',1,'']]],
  ['jsonrpc_71',['JSONRpc',['../class_server_1_1_j_s_o_n_rpc.html',1,'Server']]]
];
