var searchData=
[
  ['mainview_174',['MainView',['../class_easy_save_v2_1_1_views_1_1_main_view.html',1,'EasySaveV2::Views']]],
  ['mainwindow_175',['MainWindow',['../class_client_easy_save_v2_1_1_main_window.html',1,'ClientEasySaveV2.MainWindow'],['../class_easy_save_v2_1_1_main_window.html',1,'EasySaveV2.MainWindow']]],
  ['menuitem_176',['MenuItem',['../class_easy_save_1_1_models_1_1_menu_item.html',1,'EasySave::Models']]]
];
